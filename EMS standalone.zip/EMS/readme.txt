Update project
--------------
1. in eclipse, right click EMS project -> choose export -> WAR file -> name it to EMS.war
2. put/replace EMS.war to apache-tomcat-9.0.16\webapps


Start
------
1. run "start.bat"


Stop
----
1. run "stop.bat"