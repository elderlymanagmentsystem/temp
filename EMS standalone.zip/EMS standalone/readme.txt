================================
========    For User   =========
================================
Start EMS
---------
run "EMS.bat"
   - 1. check server status
   - 2. start server (start DB and tomcat)
   - 3. stop server (stop DB and tomcat)
   - x. Quit (only quit the menu, will not stop DB and Tomcat if they are running)

In browser visit go to http://localhost:8080/EMS/login



================================
======    For Developer  =======
================================
Update project
--------------
1. in eclipse, right click EMS project -> choose export -> WAR file -> name it to EMS.war
2. put/replace EMS.war to apache-tomcat-9.0.16\webapps



Config Tomcat
-------------
1. start server
2. in browser go to http://localhost:8080/manager/html
3. login name: admin, password: Vdocare



DB Config
---------
Recent Setting: EMS_DB
Setting Name: EMS_DB
Type: HSQL_Database Engine In-Memory
Driver: org.hsqldb.jdbcDriver
URL: jdbc:hsqldb:hsql://localhost/EMS_DB
User: SA
Password: Vdocare


To change password
------------------
If using HyberSQL, start server, start Manager.bat, login, and then run:
ALTER USER SA SET PASSWORD 'Vdocare'

** If DB password is changed, eclipse > context.xml also need to change