

function onerror(message) {
	console.error(message);
}

function zipBlob(blob, callback) {
	zipFs.root.addBlob(FILENAME, blob);
	zipFs.exportBlob(callback);
}

function unzipBlob(blob, callback) {
	zipFs.importBlob(blob, function() {
		var firstEntry = zipFs.root.children[0];
		firstEntry.getBlob(zip.getMimeType(firstEntry.name), callback);
	}, onerror);
}

function logBlobText(blob) {
	var reader = new FileReader();
	reader.onload = function(e) {
		console.log(e.target.result);
		console.log("--------------");
	};
	reader.readAsText(blob);
}


//logBlobText(blob);

